# Lecture 8: transaction costs and strategy implementation plan

Prepared 26 October 2026 after reviewing all 32 pages of `ORIE5260_Lecture_8.pdf` and the repository at `3b42f39`. At review time, both configuration and saved backtests used the 5 bps primary case. Step 1 below now updates the configuration; the saved backtests remain historical.

## Implementation status — stop after Step 5

**Steps 1–5 / Deliveries A–E are complete (26 October 2026). Steps 4–5 use explicitly conditional diagnostics because contract and funding evidence is incomplete. Step 6 / Delivery F has not started.**

Step 1 record:

- Primary cost is 2 bps; scenarios are `[0, 1, 2, 5]`. The primary band remains 10%, and signals, risk estimates and execution accounting are unchanged.
- Shared run identifiers and result selectors drive charts, metrics, alpha, class attribution, stability and printed results. Missing or ambiguous result selections fail explicitly; configuration validation checks primary membership and scenario uniqueness.
- Timing audits use the configured cost/band. Estimator comparisons export those settings and write into a specification-specific subdirectory to preserve the earlier comparison.
- The trend notebook's screening cell now specifies 1 and 2 bps and reports notional turnover. It has not been executed. Both notebooks and the README distinguish historical 5 bps conclusions from the new configuration.
- Validation: **140 tests passed**, including a synthetic end-to-end run with only 1/2 bps and a nondefault 5% band, accounting/class reconciliation, limits, alpha selection, stability and five rendered charts. The synthetic band is a regression-test fixture, not a strategy experiment or adopted setting. Modified Python files pass Ruff; both notebooks' code cells parse.
- Repository-wide checks retain **12 pre-existing Ruff findings** and **one pre-existing mypy error** at `src/portfolio_construction/targets.py:44`. The Ruff findings were verified against `HEAD`; the type-error file is unchanged. Historical report/validation outputs were not rewritten.

**Step 2 completion:** all 65 required raw files were restored and match historical hashes. Monthly reconstruction and all 24 historical baseline/v2 runs reproduce (maximum comparison difference 2.21e-13). The 32-case cost grid completed, as did class-cost attribution at 1/2 bps and the existing six-estimator sensitivity at both rates. All 32 accounting/NAV/limit checks and 140 tests pass. All 241 historical report/output files remain unchanged.

At 2 bps and the existing 10% band, baseline TREND CAGR is 11.02% (Sharpe 1.075) and v2 TREND CAGR is 11.39% (Sharpe 1.092). Matching STATIC CAGR is 5.17% (Sharpe 0.486). These are conditional, in-sample results; the preserved-policy runs still fail on the March 1997 missing held returns. The refreshed estimator diagnostic does not justify changing the risk model. The report wording now correctly explains that opposing FX signs cancel; this is a wording correction, not a signal change.

[Step 2 results and evidence](../reports/cost_revision_20261026/SUMMARY.md) include source snapshots, manifests, reference comparisons, class attribution and standalone presentation reports. Historical notebook results are retained with a dated update linked to the new results.

**Step 3 completion:** the fixed v2 TREND/STATIC grid at 0/5/10% bands and 1/2 bps completed all 12 runs. Eight shared runs reproduce Step 2; all accounting/limit checks and 143 tests pass. Turnover is decomposed into resizes, entries/exits, reversals, source close/open trades and liquidation. All 1,648 instrument-level target reversals execute in the correct direction in the same month under every band. Target tracking, four historical subperiods and 20,000-draw paired block-bootstrap intervals are recorded.

**Decision: retain the 10% band.** At 2 bps, no band raises v2 annual mean by 10.35 bps and CAGR by 8.38 bps; the 5% band's mean gain is 4.35 bps. Both gains have uncertainty intervals spanning zero, and both candidates have lower Sharpe and deeper drawdown. The no-band mean gain is positive in all four inspected subperiods, but neither candidate meets the frozen uncertainty screen. Costs saved by the 10% band do not offset its gross-return sacrifice in this sample; the decision rests on uncertain gains and the observed risk tradeoff. [Results and decision](../reports/band_experiment_20261026/SUMMARY.md).

**Step 4 completion:** audited all 62 daily files, the asset map and benchmark workbook. Contract IDs, expiries, actual roll schedules and adjustment lineage are unavailable, so no empirical historical roll model was adopted. Implemented optional dated roll schedules with explicit complete-roll/per-leg rate conversion, matched continuing-exposure accounting, no duplicated source close/open charge, combined-fee risk limits, event journals and component attribution. The primary production config remains trade-only.

The fixed 36-case v2 TREND/STATIC sensitivity uses ordinary 1/2 bps, complete-roll 1/2 bps, all three quarterly phases and monthly rolls. All event/cost/notional/class reconciliations and 167 tests pass; four trade-only controls reproduce Step 2. At ordinary 2 bps, TREND CAGR ranges from about 11.21–11.30% under quarterly assumptions and 10.85–11.12% under monthly assumptions, versus 11.39% trade-only. These are assumed incremental fees, not empirical all-in costs. [Audit, results and conventions](../reports/roll_sensitivity_20261026/SUMMARY.md).

Task-generated scratch files, Finder metadata and disposable caches were removed, with a cleanup inventory retained. Raw inputs, original Downloads files and prior result packages remain intact.

**Step 5 completion:** audited 62 daily series (457,155 rows), using 20 recorded observations with an extra bar lag and separate source histories. All 11,788 TREND and 8,661 STATIC beginning-event rows pass the descriptive positive/recent-volume screen. This is data coverage, not an executable-capacity estimate. No negative volume/OI or fractional volume was found; 730 zero-volume observations were retained.

Eight matched 2000–2014 funding cases completed at ordinary costs of 1/2 bps, with zero cash income versus the workbook RF as a conditional full-capital collateral proxy. At 2 bps, TREND CAGR is 9.41% versus 11.40%; STATIC is 7.27% versus 9.23%. Both begin flat with prior-history forecasts and end with liquidation. Income, costs, NAV and limits reconcile; 173 tests pass. The common-RF excess Sharpe is separated from the zero-rate return/volatility ratio. [Findings and evidence](../reports/implementation_feasibility_20261026/SUMMARY.md).

AUM, executable-contract metadata, calibrated impact evidence, margin schedules and actual financing terms remain missing. No capacity, nonlinear impact or borrowing model is adopted. Primary settings remain unchanged.

**Next step:** freeze selected rules and specify genuinely untouched history or prospective paper trading. Step 6 has not started. Work stops here as requested.

## 1. Decisions and lecture interpretation

**Recommended first release:** use 2 bps as the primary turnover-cost assumption, show 1 bps alongside it, and retain 0 bps as a gross-return reference and 5 bps as a historical/stress comparison. The team's instruction establishes the 1-2 bps range. Choosing its upper end as the primary reporting case is a proposed convention, not an estimate fitted to performance.

Keep the existing definition of turnover: the sum of absolute traded notional divided by beginning-period NAV, with no division by two. Thus 1-2 bps applies to each unit of one-way traded notional. A close followed by a new opening has two legs. Record this convention explicitly before comparing results with other implementations.

| Lecture pages | Finding relevant to this project | Implementation consequence |
|---|---|---|
| 6-9 | Investor outcomes depend on net performance and the instrument used to obtain exposure | Report costs alongside risk and gross returns. Keep the futures accounting convention explicit. |
| 10-12 | Futures versus ETF costs depend on holding period, funding and the form of exposure | The illustrated equity-wrapper comparisons are context, not coefficients to apply to every futures market. |
| 13-19 | Spread and market impact depend on execution, and measured cost depends on its price benchmark | Keep any estimated spread/impact component identifiable. Arrival-price shortfall and VWAP shortfall are different diagnostics. |
| 21-23 | Trading frequency, trade size, liquidity and alpha decay determine the useful cost/trading tradeoff | Re-evaluate trading bands at the new costs while measuring both saved costs and lost gross performance. |
| 24 | Fixed costs can be expressed as bps of trading value divided by portfolio value | The existing linear bps model already has the right units for the first release. |
| 25-26 | Cash financing and securities-borrow costs depend on the position and instrument | Do not infer cash borrowing directly from gross futures notional or apply stock-borrow rates mechanically to short futures. |
| 27-30 | Participation and volatility are major impact drivers; stock impact estimates are illustrated | An empirical impact model needs portfolio size, contract/liquidity data and calibration evidence. The stock figures do not calibrate this futures strategy. |
| 31 | Vendors estimate costs using trade data | Vendor estimates are an optional later data source, not a dependency for the classroom 1-2 bps proxy. |
| 32 | Managed-futures examples distinguish rolling costs from turnover-based trading/impact costs, each illustrated with 1-2 bps | Change the turnover proxy now and investigate roll activity separately. Avoid charging the same trade or spread in two components. |

Two interpretation details matter for implementation:

- Page 6's inclusion of risk in an investment objective is conceptual. The accounting identity remains gross return plus cash income minus booked costs. Volatility is not deducted from P&L as a fee.
- Page 15's displayed impact subtraction is not side-aware, while page 17 treats buying at 103.2 versus arrival 100 as a positive 3.2 cost. Any later execution-cost metric should use `side * (execution_price - benchmark_price) / benchmark_price`, with side +1 for a buy and -1 for a sell. That measures implementation shortfall; attributing all of it to causal market impact requires further evidence.

Pages 24 and 32 discuss several 1-2 bps examples. They do not establish an additive total fee applicable to every market. For the initial release, treat the team's 1-2 bps instruction as the effective turnover charge replacing 5 bps. Document its scope as an assumed aggregate trading-cost proxy. Do not automatically add another 1-2 bps commission and another 1-2 bps spread on top. A later component model must replace overlapping parts of the proxy.

## 2. Current implementation and data readiness

The primary strategy is QPS v2: commodities, equities and fixed income use the 12-month return-sum direction; FX averages the 3-month and 12-month directions. The original baseline remains available. Their risk controls are a 36-month covariance window, 50% correlation shrinkage, a 2% instrument-volatility floor, a 10% forecast-risk ceiling, a 3x gross cap and 10% relative bands.

`LinearBpsCost` already accepts any nonnegative rate. The simulator charges actual changes from drifted holdings, source close/open trades and terminal liquidation. Cost changes can alter NAV, carried holdings, band decisions and after-fee limits, so final results require rerunning the simulator.

Several consumers still hard-code 5 bps and/or a 10% band:

| Location | Required work |
|---|---|
| `config/risk_config.json` | Set the proposed primary cost to 2 and the initial scenario list to `[0, 1, 2, 5]`; keep the primary band at 0.10 for the first comparison. |
| `scripts/run_risk_research.py` | Make primary failure selection, printed metrics and run identifiers consistently use configuration. |
| `scripts/research_report.py` | Parameterize chart ledger selection, cost/band captions, primary metrics, alpha selection and the no-band comparison. |
| `src/backtest/sample_diagnostics.py` | Pass the primary specification into `stability_summary`; remove the fixed `band10_5bps` lookup. |
| `scripts/audit_timing.py` | Replace `LinearBpsCost(5)`, the fixed band and the hard-coded cost description with the selected settings. |
| `scripts/compare_risk_models.py` | Retain its existing configuration-driven cost, but export cost/band metadata in its table and isolate new outputs from the prior 5 bps experiment. |
| `notebooks/trend_measures.ipynb` | Replace the independent `COST_BPS = 5` placeholder with explicit 1 and 2 bps cases using the same convention. |
| `notebooks/risk_model_estimators.ipynb` | Refresh displayed assumptions and outputs from identified runs instead of relabeling the old 5 bps results. |
| `README.md`, methods and generated reports | State the active v2 signals, cost convention, scenarios and unresolved data assumptions accurately. |
| `scripts/verify_legacy.py`, historical fixtures and reports | Preserve the 0/5/10 bps archived reproduction cases as historical tests. They are not current primary defaults. |

Use one small shared run-key/primary-selection helper. Validate that the primary cost and band are present in their scenario lists, and reject ambiguous or missing primary result rows. A report must never display a 2 bps caption while reading a 5 bps ledger.

**Data gate at review time (resolved in Step 2):** `data/raw/` was absent in this checkout. The 65 required files are now restored and hash-verified. Committed return panels and historical ledgers are available, but the standard research runner requires the raw asset map, daily prices, monthly returns and workbook. Restore the configured inputs from the team's existing dataset before claiming a full reproducible research rerun. Configuration work, synthetic tests and fixed-path cost diagnostics can proceed first. Any future snapshot-only runner should identify its exact inputs and limitations instead of impersonating a raw-data rebuild.

The loader supports daily OHLC, volume and open interest. Their existence in the schema does not establish usable coverage in the currently absent files. The current strategy input object supplies monthly returns, an asset-class map and optional daily closes. Verified contract multipliers, expiry mappings, roll dates, spreads, execution fills and margin schedules are not supplied by that interface.

The March 1997 endpoint assumption is still unresolved. Keep both preserved-policy failure checks and the explicitly labeled conditional scenario.

## 3. First implementation: cost assumptions and a controlled rerun

1. Preserve a manifest of the current 5 bps baseline and v2 runs, including code/config/data hashes. Use a new output directory or run ID for the cost revision so the midterm reference remains reproducible.
2. Implement configuration-driven cost and band selection across the locations above.
3. Keep signals, risk estimates, eligibility, dates and execution timing fixed during this first comparison.
4. Run baseline and v2, each with TREND and STATIC, at costs `[0, 1, 2, 5]` and bands `[0, 0.10]`. This is 32 comparable runs. Treat the 0-cost case as a diagnostic and 5 bps as a legacy/stress reference.
5. Produce main results at 2 bps and an adjacent 1 bps sensitivity. Include gross and net return, CAGR, Sharpe, drawdown, turnover, direct cost drag, gross exposure and forecast calibration. Report both overall and class-level cost/return contributions.
6. Refresh the risk-estimator comparison under the new cost cases only after this reference table is correct. Label it as an update of the existing exploratory comparison, not a fresh independent validation.

### Magnitude check before rerunning

The saved v2 5 bps run has annual turnover of 7.4094 times capital for TREND and 0.7249 for STATIC. Holding that trading path fixed gives:

| Effective charge per traded notional | TREND annual direct drag | STATIC annual direct drag |
|---|---:|---:|
| 1 bps | 0.0741% | 0.00725% |
| 2 bps | 0.1482% | 0.01450% |
| 5 bps | 0.3705% | 0.03625% |

For TREND, moving from 5 to 2 bps saves approximately 22.23 bps of annual NAV on the existing path; moving to 1 bps saves 29.64 bps. These are direct arithmetic cost estimates, not new CAGR or Sharpe estimates, and exclude missing regular roll costs. Recompute the full trading path before publishing new strategy metrics.

### Acceptance checks

- Trading 0.75 units of NAV costs 0.000075 NAV at 1 bps and 0.00015 NAV at 2 bps. Instrument allocations sum to the total.
- A reversal from +0.10 to -0.10 incurs 0.20 of traded exposure. Source changes close the old source and open the new source. Entry, drift-adjusted resizes and terminal liquidation retain their existing accounting.
- On an identical fixed trade vector, doubling the bps rate doubles the charge. Do not require arbitrary endogenously rebalanced portfolios to have exactly linear performance changes.
- Gross return plus funding minus costs reconciles to net return; class contributions and NAV reconcile. Limits hold using after-fee capital.
- Signal, eligibility and order decisions remain unchanged under future-data mutation. Missing held returns still fail.
- Exercise reporting and stability diagnostics with a result set that contains 1 and 2 bps but no 5 bps row. All selected ledgers, labels and alpha rows must match the active specification.
- Reproduce the existing 5 bps results under the existing configuration before interpreting any change caused by the new rates. Keep synthetic checks independent of raw-data availability and record which end-to-end runs actually completed.

## 4. First strategy enhancement: trading bands at 1-2 bps

Lecture page 23 emphasizes preserving expected net value rather than minimizing turnover alone. The current band reduced costs at 5 bps but also reduced annual net mean in the midterm comparison. Lower execution costs may make smaller bands more attractive; that is a hypothesis to test.

After the cost-only rerun, use a small predeclared band set `[0, 0.05, 0.10]` at both 1 and 2 bps. Start with v2 and matching STATIC. Keep the signal and risk model fixed. Compare:

- Gross performance sacrificed by delaying position adjustments.
- Trading costs saved and the resulting net performance difference.
- Turnover from resizes, entries/exits, reversals and source switches.
- Drawdown, calibration, gross exposure and deviation from the unconstrained target.
- Behavior around trend reversals and in already-inspected historical blocks.

Retain the current band unless a candidate has a meaningful net advantage across both cost cases and is reasonably stable across development windows. Estimate paired uncertainty on return differences and document every tried alternative. Historical walk-forward tests can evaluate the selection procedure, but all 1976-2014 data have already informed the research. Freeze any selected rule before an untouched post-2014 or prospective test.

The sign signal is not an expected-return estimate in bps. A rule such as "trade only when expected alpha exceeds cost" needs a separately estimated, lagged expected-return model. Do not implement it by comparing a dimensionless +1/-1 signal directly with a bps charge. Keep that optimization as a later extension.

## 5. Separate roll-cost accounting

Page 32 identifies a real omission: a continuing futures exposure generally requires contract rolls even when the strategy target is unchanged. The current RL/ER source-switch accounting does not identify every ordinary expiry roll.

First establish, per market, contract identity, the held contract sequence, multiplier/quote units, currency conversion, roll dates and the vendor's continuous-return construction. Distinguish economic carry or price adjustments already in the series from execution commissions, spread and impact caused by closing one contract and opening another.

Proposed implementation:

1. Create explicit dated trade events for rebalances, source changes, expiry rolls and final liquidation. Reconcile event notionals to carried and final positions.
2. Add separate regular-trade and roll-cost fields to the ledger and instrument/class attribution, with one total cost used by NAV and the execution policy.
3. Normalize the roll-rate convention. The lecture's 1-2 bps roll example does not specify whether it covers each leg or the completed roll. For a sensitivity before clarification, label 1 and 2 bps as a provisional charge per unit of notional rolled for the complete close/open event. A per-leg quote would be converted using the actual sum of leg notionals. Never silently treat these definitions as equivalent.
4. If a source switch and scheduled roll represent the same close/open trades, identify the common event and charge it once. For coincident rolls and resizes, derive charges from the final trade list rather than independently charging a full roll plus an overlapping full rebalance.
5. Apply known beginning-period roll charges inside the fee-aware limit calculation. Appending them after position sizing can invalidate after-cost risk and exposure limits.

If exact schedules are unavailable, publish a clearly labeled assumption-based roll sensitivity using stated frequencies and rolled exposure. Do not infer exact expiry rolls from price jumps or label a uniform calendar as observed history. Show a separate trade-only result so the effect of the assumption remains visible.

Roll tests should include an unchanged position that still incurs a roll, a flat position that incurs none, two-leg versus completed-roll rate conversion, coincident resize/roll events, no duplicate source-switch charges and total/component reconciliation.

## 6. Data-gated liquidity and financing extensions

### Liquidity and market impact

The lecture motivates impact as a function of participation, volatility and duration. Add a data-readiness report before fitting anything. Required inputs include portfolio AUM, contract-level prices and multipliers, currency conversion, prior available volume, spread information and an execution horizon. Use actual execution/benchmark observations or a defensible futures-specific external calibration for model coefficients.

Participation requires consistent units: order contracts / relevant available contract volume, or order notional / notional volume. NAV weights alone cannot identify participation. Use information available before the trade for forecast liquidity. Do not feed the holding month's full realized volume into the decision or assume synthetic merged-series volume is the volume of an executable contract.

A future model may expose `trade context` plus a component cost breakdown. Preserve the simple linear model as a supported implementation. Use the same cost quote when deciding positions and when booking their costs. Treat half-spread as a per-side crossing estimate when appropriate; avoid adding a full spread twice or double-counting impact already present in an aggregate proxy.

Adding nonlinear or per-market costs requires revisiting `enforce_limits`: its present scalar bound and bisection checks assume the current linear form. Verify feasibility and monotonicity or replace the solver. Do not plug in an arbitrary nonlinear impact model and assume the current solver remains valid.

Until the data gate is met, report scenarios and limitations rather than a fitted capacity estimate. Daily OHLC cannot recreate arrival prices, execution VWAP or realized implementation shortfall.

### Margin, collateral and cash funding

Keep gross futures exposure as a risk/exposure statistic. If reliable margin schedules are available, estimate margin usage from contracts and applicable requirements, then model cash borrowing only when actual funding is needed. Report margin utilization and a cash buffer alongside gross exposure.

Any annual funding spread must be applied to the funded amount over the actual holding period, with collateral interest tracked separately. Reconcile this with the simulator's existing `risk_free`/collateral-income handling and documented return-series conventions. The lecture's illustrative stock-borrow rates and leveraged physical-equity example are not universal futures fees.

These extensions depend on contract metadata and financing assumptions. They should not delay the first 1-2 bps turnover-cost implementation.

## 7. Research controls and delivery sequence

The initial cost revision changes only the cost assumption and reporting selection. The current 36-month risk estimator remains the reference. The earlier faster-estimator experiment did not resolve calibration. A later shrinkage experiment can follow after costs and bands are evaluated, using the already documented diagnostic as a hypothesis rather than a demonstrated improvement. Do not change signals, covariance weights, shrinkage, class budgets and trading bands simultaneously.

Keep baseline/v2 and TREND/STATIC comparisons on the same dates, data scenario and cost convention. For claims about directional skill, add the planned comparisons at common gross exposure or comparable ex ante risk, and separate equal-notional versus inverse-volatility sizing. The FX blend was chosen after observing historical results and still needs independent validation.

| Delivery | Contents | Completion criterion |
|---|---|---|
| A. Cost configuration and selection | Shared selectors, 2 bps primary, 1 bps sensitivity, metadata and synthetic checks | No active consumer silently assumes 5 bps; historical reproduction remains available. |
| B. Comparable cost results | Restore raw inputs, reproduce reference, run the 32-case comparison and regenerate reports | All figures and tables identify the same run, costs reconcile, conditional data status is explicit. |
| C. Band experiment | Predeclared 0/5/10% relative bands at 1 and 2 bps | Net benefit and uncertainty documented, with a recorded decision and no automatic promotion from best in-sample Sharpe. |
| D. Roll costs | Data audit, explicit events where possible, otherwise assumption-based sensitivity | Rate basis, roll frequency, overlap treatment and attribution are inspectable. |
| E. Liquidity/funding research | Data inventory, feasibility assessment and only supported models | Every empirical coefficient and notional conversion has evidence; unsupported assumptions are labeled. |
| F. Final evaluation | Freeze selected rules and run untouched history or prospective paper trading | Evaluate net value, costs, risk calibration, drawdowns and exposures together. |

A completed report should distinguish gross returns, ordinary trade costs, roll costs, any supported funding costs and net returns; state AUM only when capacity assumptions require it; show 1 and 2 bps prominently; and retain the endpoint qualification. The lecture provides cost-modeling principles and illustrative rates. Adoption of a new strategy rule still requires evidence from the controlled comparisons above.
